document.getElementById('analyze-button').addEventListener('click', () => {
    fetch('/analyze_color/')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const resultDiv = document.getElementById('result');
            if (data.faces.length > 0) {
                resultDiv.innerHTML = data.faces.map(face =>
                    `<p>Detected Color: ${face.color}</p>`
                ).join('');
            } else {
                resultDiv.innerHTML = '<p>No faces detected. Please try again.</p>';
            }
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            document.getElementById('result').innerHTML = '<p>An error occurred. Please try again.</p>';
        });
});