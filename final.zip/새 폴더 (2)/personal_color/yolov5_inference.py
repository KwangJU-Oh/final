import numpy as np

# Yolov5를 사용하는 얼굴 감지 클래스는 그대로 사용
class Yolov5FaceDetector:
    def __init__(self):
        import torch
        self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
        self.model.classes = [0]  # 사람 클래스만 감지 (0: person)

    def detect_faces(self, frame):
        results = self.model(frame)
        return results.pandas().xyxy[0]  # 결과를 DataFrame으로 반환


# 경량화된 퍼스널 컬러 추천 함수
def recommend_personal_color(face_image):
    # 얼굴 이미지의 평균 RGB 값 계산
    avg_color = np.mean(face_image, axis=(0, 1))  # 채널별 평균값 [B, G, R]
    r, g, b = avg_color[2], avg_color[1], avg_color[0]  # OpenCV는 BGR이므로 순서 변경

    # 퍼스널 컬러 추천 로직
    if r > b and g > b:
        return "Warm Tone"
    elif b > r and b > g:
        return "Cool Tone"
    else:
        return "Neutral Tone"