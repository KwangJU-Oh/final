# personal_color/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('analyze_color/', views.analyze_color, name='analyze_color'),
]