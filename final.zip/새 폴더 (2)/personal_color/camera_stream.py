# personal_color/camera_stream.py

import cv2

class VideoCamera:
    _instance = None  # 싱글턴 인스턴스

    def __new__(cls, camera_index=0):
        if cls._instance is None:
            cls._instance = super(VideoCamera, cls).__new__(cls)
            cls._instance.video = cv2.VideoCapture(camera_index)
            if not cls._instance.video.isOpened():
                raise Exception("Unable to access the camera")
        return cls._instance

    def __del__(self):
        if self.video.isOpened():
            self.video.release()

    def get_frame(self):
        # 읽기 전 버퍼 비우기
        self.video.set(cv2.CAP_PROP_POS_FRAMES, 0)
        success, frame = self.video.read()
        if success:
            return frame
        else:
            raise Exception("Unable to read frame from camera")
