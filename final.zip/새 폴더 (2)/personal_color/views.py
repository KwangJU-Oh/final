# personal_color/views.py

from django.http import JsonResponse
from django.views.decorators.cache import never_cache

from .yolov5_inference import Yolov5FaceDetector, recommend_personal_color
from .camera_stream import VideoCamera
import os
import cv2
from django.conf import settings

detector = Yolov5FaceDetector()

# 얼굴 감지 및 경량 퍼스널 컬러 분석
@never_cache
def analyze_color(request):
    try:
        camera = VideoCamera()  # 싱글턴 객체 사용
        frame = camera.get_frame()  # 최신 프레임 강제 가져오기

        # Yolov5로 얼굴 감지
        results = detector.detect_faces(frame)
        faces = []
        saved_images = []

        for i, (_, row) in enumerate(results.iterrows()):
            # 얼굴 영역 크롭
            x1, y1, x2, y2 = map(int, [row['xmin'], row['ymin'], row['xmax'], row['ymax']])
            face = frame[y1:y2, x1:x2]

            if face.size == 0:
                continue

            # 퍼스널 컬러 분석
            color = recommend_personal_color(face)

            # 얼굴 이미지 저장
            output_dir = os.path.join(settings.MEDIA_ROOT, 'analyzed_faces')
            os.makedirs(output_dir, exist_ok=True)
            image_path = os.path.join(output_dir, f'face_{i}.jpg')
            cv2.imwrite(image_path, face)

            # 저장된 이미지의 URL 생성
            image_url = f'/media/analyzed_faces/face_{i}.jpg'
            saved_images.append(image_url)

            # 얼굴 결과 추가
            faces.append({'box': [x1, y1, x2, y2], 'color': color, 'image_url': image_url})

        return JsonResponse({'faces': faces})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

from django.shortcuts import render


# 메인 페이지 (index)
def index(request):
    return render(request, 'personal_color/index.html')